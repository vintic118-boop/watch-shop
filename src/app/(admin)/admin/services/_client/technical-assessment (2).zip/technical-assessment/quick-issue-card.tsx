"use client";

import { Wrench } from "lucide-react";
import { cn } from "@/lib/utils"


type QuickIssueCardProps = {
    title: string;
    description?: string | null;
    isOpen?: boolean;
    disabled?: boolean;
    onToggle: () => void;
    rightSlot?: React.ReactNode;
    className?: string;
};

export function QuickIssueCard({
    title,
    description,
    isOpen = false,
    disabled,
    onToggle,
    rightSlot,
    className,
}: QuickIssueCardProps) {
    return (
        <div
            className={cn(
                "rounded-[20px] border border-slate-200 bg-white p-4 shadow-sm transition",
                className
            )}
        >
            <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-start gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-100">
                        <Wrench className="h-4 w-4 text-slate-600" />
                    </div>

                    <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900">{title}</div>
                        <div className="mt-1 text-sm text-slate-500">
                            {description?.trim()
                                ? description
                                : "Không phát sinh issue ở hạng mục này."}
                        </div>
                    </div>
                </div>

                <div className="shrink-0">
                    {rightSlot ?? (
                        <button
                            type="button"
                            onClick={onToggle}
                            disabled={disabled}
                            className={cn(
                                "inline-flex h-10 items-center rounded-xl border px-4 text-sm font-medium transition",
                                isOpen
                                    ? "border-slate-300 bg-slate-100 text-slate-900"
                                    : "border-slate-200 bg-white text-slate-900 hover:bg-slate-50",
                                disabled && "cursor-not-allowed opacity-60"
                            )}
                        >
                            {isOpen ? "Bỏ issue" : "Mở issue"}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}

export default QuickIssueCard;