export * from "../acquisition.dto";
