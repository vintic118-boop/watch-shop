import { normalizeKey } from "@/server/lib/product-image-storage";
import { moveMediaObject } from "@/server/lib/media-storage";

export const ACQUISITION_INLINE_IMAGE_PREFIX = "products/inline/chosen";

export async function prepareAcquisitionInlineImage(fileKey: string) {
  const normalized = normalizeKey(fileKey);
  if (!normalized) {
    throw new Error("Thiếu fileKey.");
  }

  const moved = await moveMediaObject({
    fromKey: normalized,
    toPrefix: ACQUISITION_INLINE_IMAGE_PREFIX,
    deleteSource: true,
    overwrite: false,
  });

  const key = normalizeKey(moved.key);

  return {
    key,
    url: `/api/media/sign?key=${encodeURIComponent(key)}`,
    fromKey: normalizeKey(moved.fromKey),
    copied: moved.copied,
    deleted: moved.deleted,
  };
}
