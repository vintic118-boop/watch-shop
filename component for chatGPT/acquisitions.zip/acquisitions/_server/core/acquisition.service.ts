export * from "../acquisition.service";
