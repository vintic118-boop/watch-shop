"use client";

import { useState } from "react";
import { Loader2, Trash2 } from "lucide-react";
import MediaPickerInline from "@/components/media/MediaPickerInline";
import type { AcquisitionWatchLine } from "../_server/acquisition-line.types";

type Props = {
    line: AcquisitionWatchLine;
    index: number;
    onChange: (next: AcquisitionWatchLine) => void;
    onRemove: () => void;
    canRemove?: boolean;
};

export default function WatchLineCard({
    line,
    index,
    onChange,
    onRemove,
    canRemove = true,
}: Props) {
    const [movingImage, setMovingImage] = useState(false);

    const setField = <K extends keyof AcquisitionWatchLine>(
        key: K,
        value: AcquisitionWatchLine[K]
    ) => {
        onChange({ ...line, [key]: value });
    };

    const handlePickImage = async (fileKey: string) => {
        if (!fileKey) return;
        setMovingImage(true);

        try {
            const res = await fetch("/api/admin/acquisitions/prepare-inline-image", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ fileKey }),
            });

            const data = await res.json().catch(() => null);
            if (!res.ok) {
                throw new Error(data?.error || "Không thể xử lý ảnh đã chọn.");
            }

            onChange({
                ...line,
                imageKey: data.key ?? null,
                imageUrl: data.url ?? null,
            });
        } catch (error: any) {
            alert(error?.message || "Không thể xử lý ảnh đã chọn.");
        } finally {
            setMovingImage(false);
        }
    };

    return (
        <div className="rounded-2xl border border-slate-200 bg-white px-4 py-4">
            <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <div className="rounded-full border border-slate-200 px-3 py-1 text-sm font-medium text-slate-700">
                        Đồng hồ #{index + 1}
                    </div>
                    {!line.quickInput ? (
                        <div className="rounded-full bg-amber-50 px-3 py-1 text-xs text-amber-700">
                            Trống
                        </div>
                    ) : null}
                    {movingImage ? (
                        <div className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            Đang xử lý ảnh
                        </div>
                    ) : null}
                </div>

                {canRemove ? (
                    <button
                        type="button"
                        onClick={onRemove}
                        className="inline-flex items-center gap-1 text-sm text-rose-600 hover:text-rose-700"
                    >
                        <Trash2 className="h-4 w-4" />
                        Xóa
                    </button>
                ) : null}
            </div>

            <div className="grid grid-cols-1 gap-3 xl:grid-cols-[84px_minmax(0,1.5fr)_minmax(0,1.2fr)_90px_140px_110px] xl:items-start">
                <div className="space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        Ảnh
                    </div>
                    <MediaPickerInline
                        value={line.imageUrl || line.imageKey}
                        onChange={handlePickImage}
                        pending={movingImage}
                        disabled={movingImage}
                        profile="inline/active"
                        compact
                        className="h-[72px] w-[72px] rounded-xl"
                    />
                </div>

                <div className="space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        Mô tả nhanh / tên đồng hồ
                    </div>
                    <input
                        value={line.quickInput}
                        onChange={(e) => setField("quickInput", e.target.value)}
                        placeholder="VD: seiko tự động tròn mặt đen dây thép"
                        className="h-[42px] w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-300 focus:ring-2 focus:ring-slate-100"
                    />
                </div>

                <div className="space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        Gợi ý thêm cho AI
                    </div>
                    <input
                        value={line.aiHint}
                        onChange={(e) => setField("aiHint", e.target.value)}
                        placeholder="VD: niềng 18K gold, máy pin..."
                        className="h-[42px] w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-300 focus:ring-2 focus:ring-slate-100"
                    />
                </div>

                <div className="space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        SL
                    </div>
                    <input
                        type="number"
                        value={line.quantity}
                        onChange={(e) => setField("quantity", Number(e.target.value || 1))}
                        className="h-[42px] w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-300 focus:ring-2 focus:ring-slate-100"
                    />
                </div>

                <div className="space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        Giá nhập
                    </div>
                    <input
                        type="number"
                        value={line.cost}
                        onChange={(e) =>
                            setField("cost", e.target.value === "" ? "" : Number(e.target.value))
                        }
                        className="h-[42px] w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-slate-300 focus:ring-2 focus:ring-slate-100"
                    />
                </div>

                <div className="space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-500">
                        Service
                    </div>
                    <label className="inline-flex h-[42px] items-center gap-2 rounded-xl border border-slate-200 px-3 text-sm text-slate-700">
                        <input
                            type="checkbox"
                            checked={line.receiveService}
                            onChange={(e) => setField("receiveService", e.target.checked)}
                        />
                        <span>Có</span>
                    </label>
                </div>
            </div>
        </div>
    );
}
