import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePermissionApi } from "@/server/auth/requirePermissionApi";
import { PERMISSIONS } from "@/constants/permissions";
import { prepareAcquisitionInlineImage } from "@/app/(admin)/admin/acquisitions/_server/core/acquisition-media.service";

const BodySchema = z.object({
    fileKey: z.string().min(1),
});

export async function POST(req: NextRequest) {
    const auth = await requirePermissionApi(PERMISSIONS.PRODUCT_CREATE);
    if (auth instanceof Response) return auth;

    try {
        const body = BodySchema.parse(await req.json());
        const prepared = await prepareAcquisitionInlineImage(body.fileKey);
        return NextResponse.json({ success: true, ...prepared });
    } catch (error: any) {
        return NextResponse.json(
            { error: error?.message || "Prepare inline image failed" },
            { status: 400 }
        );
    }
}
