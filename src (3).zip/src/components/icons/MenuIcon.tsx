import { IconPropsModel } from "@/models/common/CommonModels";

export default function MenuIcon({
    width = 20,
    height = 20,
    color = "#000000",
}: IconPropsModel) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width={width} height={height} fill="none" viewBox="0 0 18 16">
            <path d="M1 .5a.5.5 0 100 1h15.71a.5.5 0 000-1H1zM.5 8a.5.5 0 01.5-.5h15.71a.5.5 0 010 1H1A.5.5 0 01.5 8zm0 7a.5.5 0 01.5-.5h15.71a.5.5 0 010 1H1a.5.5 0 01-.5-.5z" fill={color}>
            </path>
        </svg>
    );
}